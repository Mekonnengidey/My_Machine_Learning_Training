Folder for notebooks related to LLM work.
